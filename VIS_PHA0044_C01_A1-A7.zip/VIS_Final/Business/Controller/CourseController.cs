﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.DB_DAO;
using Data.Table;

namespace Business.Controller
{
    public class CourseController
    {
        public void UpdateStudentCourse(int id, string course)
        {
            CourseTable.UpdateStudentCourse(id, course);
        } 

    }
}
