﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Class;
using Data.DB_DAO;
using Data.Table;

namespace Business.Controller
{
    public class ThesisController
    {
        public void InsertThesis(Thesis thesis)
        {
            ThesisDB myThesis = new ThesisDB();
            myThesis.name = thesis.name;
            myThesis.describtion = thesis.describtion;
            ThesisTable.Insert(myThesis);
        }

        public void UpdateThesis(Thesis thesis)
        {
            ThesisDB myThesis = new ThesisDB();
            myThesis.name = thesis.name;
            myThesis.describtion = thesis.describtion;
            ThesisTable.Update(myThesis);


        }

        public void SelectThesis(int id)
        {
            ThesisTable.Select(id);
        }

        public void DeleteThesis(int id)
        {
            ThesisTable.Delete(id);
        }

        public List<string> SelectDes()
        {
            return ThesisTable.SelectName();
        }

        public string SelectSingleDes(string name)
        {
            return ThesisTable.SelectSingleDes(name);
        }

        public void UpdateThesis(int id, string name)
        {
            ThesisTable.UpdateThesis(id, name);
        }

    }
}

//private static string ReadDes(SqlDataReader reader)
//{
//    //Collection<ThesisDB> Thesiss = new Collection<ThesisDB>();

//    string Des = " ";
//    while (reader.Read())
//    {
//        int i = 0;
//        Des = reader.GetString(0);
//    }
//    return Des;
//}

//private static List<string> ReadDes(SqlDataReader reader)
//{
//    //Collection<ThesisDB> Thesiss = new Collection<ThesisDB>();


//    List<string> ThesisList = new List<string>();
//    while (reader.Read())
//    {
//        int i = 0;
//        ThesisDB thesis = new ThesisDB();
//        thesis.name = reader.GetString(++i);
//        thesis.describtion = reader.GetString(++i);
//    }
//    return ThesisList;
//}



//public static ThesisDB Select(int id)
//{
//    Database db;

//    db = new Database();
//    db.Connect();


//    SqlCommand command = db.CreateCommand(SQL_SELECT_ID);

//    command.Parameters.AddWithValue("@id", id);
//    SqlDataReader reader = db.Select(command);

//    Collection<ThesisDB> Thesiss = Read(reader);
//    ThesisDB ThesisDB = null;
//    if (Thesiss.Count == 1)
//    {
//        ThesisDB = Thesiss[0];
//    }
//    reader.Close();

//    db.Close();
//    return ThesisDB;
//}

//public static string SelectDes(string name)
//{
//    Database db;

//    db = new Database();
//    db.Connect();


//    SqlCommand command = db.CreateCommand(SQL_Select_Des);

//    command.Parameters.AddWithValue("@name", name);
//    SqlDataReader reader = db.Select(command);

//    string Des = ReadDes(reader);

//    List<ThesisDB> Thesiss = ReadDes(reader);
//    ThesisDB ThesisDB = null;
//    if (Thesiss.Count == 1)
//    {
//        ThesisDB = Thesiss[0];
//    }
//    reader.Close();

//    reader.Close();

//    db.Close();
//    return Des;
//}
