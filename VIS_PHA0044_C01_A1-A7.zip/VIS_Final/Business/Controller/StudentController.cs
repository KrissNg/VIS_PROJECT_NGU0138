﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.DB_DAO;
using Data.Table;

namespace Business.Controller
{
    public class StudentController
    {
        public void InsertStudent(Student student)
        {
            StudentDB myStudent = new StudentDB();
            myStudent.fname = student.fname;
            myStudent.lname = student.lname;
            myStudent.age = student.age;
            myStudent.gender = student.gender;
            myStudent.grade = student.grade;
            myStudent.credit = student.credit;
            StudentTable.Insert(myStudent);
        }
        public void UpdateStudent(Student student)
        {
            StudentDB myStudent = new StudentDB();
            myStudent.fname = student.fname;
            myStudent.lname = student.lname;
            myStudent.age = student.age;
            myStudent.gender = student.gender;
            myStudent.phone = student.phone;
            myStudent.grade = student.grade;
            myStudent.credit = student.credit;
            StudentTable.Update(myStudent);
        }

        public void SelectStudent(int id)
        {
            StudentTable.Select(id);
        }

        public void DeleteStudent(int id)
        {
            StudentTable.Delete(id);
        }

        public int SelectCredit(int id)
        {
            return StudentTable.SelectCredit(id);
        }

        public void UpdateStudent(string name, string email, int phone)
        {
            StudentTable.UpdateStudent(name, email, phone);
        }



    }
}
