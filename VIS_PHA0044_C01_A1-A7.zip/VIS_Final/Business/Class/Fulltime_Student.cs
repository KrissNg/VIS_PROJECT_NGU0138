﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    class Fulltime_Student : Student
    {
        private int id { get; set; }
        
        public Fulltime_Student(string fname, string lname, int age, int gender)
        {
            this.fname = fname;
            this.lname = lname;
            this.age = age;
            this.gender = gender;
        }

        public int getID()
        {
            return id;
        }
    }
}
