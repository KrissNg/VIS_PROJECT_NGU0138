﻿using System;
using System.Collections.Generic;
using Business;
using Business.Class;
using Business.Controller;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            SelectThesis(19);

        }

        #region Thesis Selection Use Case

        public static void UpdateThesis(int id, string name)
        {
            ThesisController tConstroller = new ThesisController();
            tConstroller.UpdateThesis(id, name);
        }

        public static void InsertStudent(string fname, string lname, int age, int gender, int grade, int credit)
        {
            StudentController sController = new StudentController();
            Student mystudent = new Student();

            mystudent.fname = fname;
            mystudent.lname = lname;
            mystudent.age = age;
            mystudent.gender = gender;
            mystudent.grade = grade;
            mystudent.credit = credit;
            sController.InsertStudent(mystudent);
        }

        public static void ThesisSelect(string sID, string thesis)
        {
            StudentController sController = new StudentController();
            Student mystudent = new Student();



        }

        public static void ShowThesis()
        {

            ThesisController tController = new ThesisController();
            List<string> callDes = tController.SelectDes();

            foreach (var thesis in callDes)
            {
                string thesisDes = thesis;
                Console.WriteLine(thesisDes + "\n");
            }

            //Console.WriteLine(tController.SelectDes()[0].Item1);

        }

        public static string DisplayThesisDes(string name)
        {
            ThesisController tController = new ThesisController();
            return tController.SelectSingleDes(name);
        }

        public static int SelectCredit(int id)
        {
            StudentController sController = new StudentController();
            return sController.SelectCredit(id);
        }

        //MAIN FUNCTION FOR USE CASE
        public static void SelectThesis(int studentID)
        {
            int studentCredit = 0;
            studentCredit = SelectCredit(studentID);

            if (studentCredit < 60)
            {
                Console.WriteLine("You are uneligible to assign for the thesis !");
            }
            else
            {
                try
                {
                    string answer = "no";
                    string selection = "";
                    while (answer == "no")
                    {
                        ShowThesis();
                        Console.WriteLine("Select your thesis: ");
                        selection = Console.ReadLine();

                        Console.WriteLine(selection + " info: " + "\n");
                        Console.WriteLine(DisplayThesisDes(selection));
                        Console.WriteLine("Confirm your selection ? \n yes/no");
                        string studentAnswer = Console.ReadLine();
                        answer = studentAnswer;
                    }
                    UpdateThesis(studentID, selection);
                    Console.WriteLine("Thesis updated, you assigned for " + selection);

                }
                catch(InvalidCastException e)
                {
                    Console.WriteLine("Something wrong happened: " + e);
                }
               
            }
        }
        #endregion

        #region Course Register Use Case
        public static void RegistCourse(int studentId, string courseName)
        {
            CourseController cController = new CourseController();
            cController.UpdateStudentCourse(studentId, courseName);
        }
        #endregion
    }
}

