﻿using Data.Table;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.DB_DAO
{
    public class CourseTable
    {
        public static String SQL_SELECT = "SELECT * FROM \"Course\"";
        public static String SQL_SELECT_ID = "SELECT * FROM \"Course\" WHERE id=@id";
        public static String SQL_INSERT = "INSERT INTO \"Course\" VALUES (@id, @name, @credit, @student_id)";
        public static String SQL_DELETE_ID = "DELETE FROM \"Course\" WHERE id=@id";
        public static String SQL_UPDATE = "UPDATE \"Course\" SET id=@id, name=@name, credit=@credit, student_id = @student_id";
        public static String SQL_Update_Course = "Update course set student_id = (select id from student where id = @id) where name = @name ";

        private static void PrepareUpdateCourseCommand(SqlCommand command, int id, string name)
        {
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@name", name);
        }



        public static int UpdateStudentCourse(int id, string name)
        {
            Database db;
                db = new Database();
                db.Connect();
            

            SqlCommand command = db.CreateCommand(SQL_Update_Course);
            PrepareUpdateCourseCommand(command, id, name);
            int ret = db.ExecuteNonQuery(command);

            db.Close();


            return ret;
        }

        public static int Insert(CourseDB course, Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            SqlCommand command = db.CreateCommand(SQL_INSERT);
            PrepareCommand(command, course);
            int ret = db.ExecuteNonQuery(command);

            if (pDb == null)
            {
                db.Close();
            }

            return ret;
        }

        /// <summary>
        /// Update the record.
        /// </summary>
        public static int Update(CourseDB course, Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            SqlCommand command = db.CreateCommand(SQL_UPDATE);
            PrepareCommand(command, course);
            int ret = db.ExecuteNonQuery(command);

            if (pDb == null)
            {
                db.Close();
            }

            return ret;
        }


        /// <summary>
        /// Select the records.
        /// </summary>
        public static Collection<CourseDB> Select(Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            SqlCommand command = db.CreateCommand(SQL_SELECT);
            SqlDataReader reader = db.Select(command);

            Collection<CourseDB> users = Read(reader);
            reader.Close();

            if (pDb == null)
            {
                db.Close();
            }

            return users;
        }

        /// <summary>
        /// Select the record.
        /// </summary>
        /// <param name="id">course id</param>
        public static CourseDB Select(int id, Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            SqlCommand command = db.CreateCommand(SQL_SELECT_ID);

            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = db.Select(command);

            Collection<CourseDB> Courses = Read(reader);
            CourseDB CourseDB = null;
            if (Courses.Count == 1)
            {
                CourseDB = Courses[0];
            }
            reader.Close();

            if (pDb == null)
            {
                db.Close();
            }

            return CourseDB;
        }

        /// <summary>
        /// Delete the record.
        /// </summary>
        /// <param name="idCourse">course id</param>
        /// <returns></returns>
        public static int Delete(int idCourse, Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }
            SqlCommand command = db.CreateCommand(SQL_DELETE_ID);

            command.Parameters.AddWithValue("@id", idCourse);
            int ret = db.ExecuteNonQuery(command);

            if (pDb == null)
            {
                db.Close();
            }

            return ret;
        }

        /// <summary>
        ///  Prepare a command.
        /// </summary>
        private static void PrepareCommand(SqlCommand command, CourseDB CourseDB)
        {
            command.Parameters.AddWithValue("@id", CourseDB.id);
            command.Parameters.AddWithValue("@name", CourseDB.name);
            command.Parameters.AddWithValue("@credit", CourseDB.credit);
            command.Parameters.AddWithValue("@student_id", CourseDB.student_id);
        }

        private static Collection<CourseDB> Read(SqlDataReader reader)
        {
            Collection<CourseDB> users = new Collection<CourseDB>();

            while (reader.Read())
            {
                int i = -1;
                CourseDB course = new CourseDB();
                course.id = reader.GetInt32(++i);
                course.name = reader.GetString(++i);
                course.credit = reader.GetInt32(++i);
                course.student_id = reader.GetInt32(++i);

                users.Add(course);
            }
            return users;
        }

        public static string CreateCourse(string name, int credit, int student_Id,Database pDb)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            // 1.  create a command object identifying the stored procedure
            SqlCommand command = db.CreateCommand("CreateCourse");

            // 2. set the command object so it knows to execute a stored procedure
            command.CommandType = CommandType.StoredProcedure;

            // 3. create input parameters

            SqlParameter inputName = new SqlParameter();
            inputName.ParameterName = "@name";
            inputName.DbType = DbType.String;
            inputName.Value = name;
            inputName.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputName);

            SqlParameter inputCredit = new SqlParameter();
            inputCredit.ParameterName = "@credit";
            inputCredit.DbType = DbType.Int32;
            inputCredit.Value = credit;
            inputCredit.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputCredit);

            SqlParameter inputStudentID = new SqlParameter();
            inputStudentID.ParameterName = "@student_id";
            inputStudentID.DbType = DbType.Int32;
            inputStudentID.Value = student_Id;
            inputStudentID.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputStudentID);

            // 3. create output parameters
            SqlParameter output = new SqlParameter();
            output.ParameterName = "@result";
            output.DbType = DbType.Int32;
            output.Direction = ParameterDirection.Output;
            command.Parameters.Add(output);

            // 4. execute procedure
            int ret = db.ExecuteNonQuery(command);

            // 5. get values of the output parameters
            string result = command.Parameters["@result"].Value.ToString();

            if (pDb == null)
            {
                db.Close();
            }
            return result;
        }
    }
}
