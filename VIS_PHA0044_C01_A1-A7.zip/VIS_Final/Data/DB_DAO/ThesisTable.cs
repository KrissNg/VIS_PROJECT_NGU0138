﻿
using Data.Table;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.DB_DAO
{
    public class ThesisTable
    {
        public static String SQL_SELECT = "SELECT * FROM \"Thesis\"";
        public static String SQL_SELECT_ID = "SELECT * FROM \"Thesis\" WHERE id=@id";
        public static String SQL_INSERT = "INSERT INTO \"Thesis\"(name,describtion,tutor_id) VALUES (@name, @describtion,@tutor_id)";
        public static String SQL_DELETE_ID = "DELETE FROM \"Thesis\" WHERE id=@id";
        public static String SQL_UPDATE = "UPDATE \"Thesis\" SET name=@name, describtion=@describtion, student_id=@student_id, tutor_id=@tutor_id WHERE id = @id";
        public static String SQL_Select_Des = "Select name from \"Thesis\"";
        public static String SQL_Select_Thesis = "Select credit from student where id = @id";
        public static String SQL_Display_Des = "Select describtion from thesis where name = @name";
        public static String SQL_Update_Thesis = "update thesis set student_id = (select id from student where id = @id) where name = @name  ";

        private static void PrepareUpdateThesisCommand(SqlCommand command, int studenID, string thesisName)
        {
            command.Parameters.AddWithValue("@id", studenID);
            command.Parameters.AddWithValue("@name", thesisName);
        }

        public static int UpdateThesis(int studenID, string thesisName)
        {
            Database db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_Update_Thesis);
            PrepareUpdateThesisCommand(command, studenID, thesisName);
            int ret = db.ExecuteNonQuery(command);

            db.Close();
            return ret;
        }

        private static string ReadSingleDes(SqlDataReader reader)
        {
            //Collection<ThesisDB> Thesiss = new Collection<ThesisDB>();

            string Des = " ";
            while (reader.Read())
            {
                int i = 0;
                Des = reader.GetString(0);
            }
            return Des;
        }

        public static string SelectSingleDes(string name)
        {
            Database db;

            db = new Database();
            db.Connect();


            SqlCommand command = db.CreateCommand(SQL_Display_Des);

            command.Parameters.AddWithValue("@name", name);
            SqlDataReader reader = db.Select(command);

            string Des = ReadSingleDes(reader);


            reader.Close();

            return Des;
        }

        public static List<string> SelectName()
        {
            Database db;

            db = new Database();
            db.Connect();


            SqlCommand command = db.CreateCommand(SQL_Select_Des);

            //command.Parameters.AddWithValue("@name", name);

            SqlDataReader reader = db.Select(command);

            List<string> Name = ReadDes(reader);
            //Des = ReadDes(reader);

            reader.Close();

            db.Close();
            return Name;
        }


        public static int Insert(ThesisDB Thesis)
        {
            Database db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_INSERT);
            PrepareCommand(command, Thesis);
            int ret = db.ExecuteNonQuery(command);

            db.Close();
            return ret;
        }

        /// <summary>
        /// Update the record.
        /// </summary>
        /// 

        public static int Update(ThesisDB Thesis)
        {
            Database db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_UPDATE);
            PrepareCommand(command, Thesis);
            int ret = db.ExecuteNonQuery(command);

            db.Close();
            return ret;
        }


        /// <summary>
        /// Select the records.
        /// </summary>
        public static Collection<ThesisDB> Select(Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            SqlCommand command = db.CreateCommand(SQL_SELECT);
            SqlDataReader reader = db.Select(command);

            Collection<ThesisDB> Thesiss = Read(reader);
            reader.Close();

            if (pDb == null)
            {
                db.Close();
            }

            return Thesiss;
        }

        /// <summary>
        /// Select the record.
        /// </summary>
        /// <param name="id">Thesis id</param>
        public static ThesisDB Select(int id)
        {
            Database db;

            db = new Database();
            db.Connect();


            SqlCommand command = db.CreateCommand(SQL_SELECT_ID);

            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = db.Select(command);

            Collection<ThesisDB> Thesiss = Read(reader);
            ThesisDB ThesisDB = null;
            if (Thesiss.Count == 1)
            {
                ThesisDB = Thesiss[0];
            }
            reader.Close();

            db.Close();
            return ThesisDB;
        }

        /// <summary>
        /// Delete the record.
        /// </summary>
        /// <param name="idUser">Thesis id</param>
        /// <returns></returns>
        public static int Delete(int idUser, Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }
            SqlCommand command = db.CreateCommand(SQL_DELETE_ID);

            command.Parameters.AddWithValue("@id", idUser);
            int ret = db.ExecuteNonQuery(command);

            if (pDb == null)
            {
                db.Close();
            }

            return ret;
        }

        /// <summary>
        ///  Prepare a command.
        /// </summary>
        

        private static Collection<ThesisDB> Read(SqlDataReader reader)
        {
            Collection<ThesisDB> Thesiss = new Collection<ThesisDB>();

            while (reader.Read())
            {
                int i = -1;
                ThesisDB Thesis = new ThesisDB();
                Thesis.id = reader.GetInt32(i++);
                Thesis.name = reader.GetString(++i);
                Thesis.describtion = reader.GetString(++i);
                Thesis.student_id = reader.GetInt32(++i);
                Thesis.tutor_id = reader.GetInt32(++i);
                Thesiss.Add(Thesis);
            }
            return Thesiss;
        }

        private static List<string> ReadDes(SqlDataReader reader)
        {
            //Collection<ThesisDB> Thesiss = new Collection<ThesisDB>();


            List<string> Thesiss = new List<string>();

            string myThesis = "";

            while (reader.Read())
            {
                int i = -1;

                
                myThesis = (reader.GetString(++i));
                //myThesis. = reader.GetString(++i);
                //myThesis.describtion = reader.GetString(++i);

                Thesiss.Add(myThesis);
            }
            return Thesiss;

        }

        private static void PrepareCommand(SqlCommand command, ThesisDB ThesisDB)
        {
            command.Parameters.AddWithValue("@name", ThesisDB.name);
            command.Parameters.AddWithValue("@describtion", ThesisDB.describtion);
            command.Parameters.AddWithValue("@tutor_id", ThesisDB.tutor_id);
        }

        public static string CreateThesis(string name, string describtion, int tutor_id, Database pDb)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            // 1.  create a command object identifying the stored procedure
            SqlCommand command = db.CreateCommand("CreateThesis");

            // 2. set the command object so it knows to execute a stored procedure
            command.CommandType = CommandType.StoredProcedure;

            // 3. create input parameters

            SqlParameter inputName = new SqlParameter();
            inputName.ParameterName = "@name";
            inputName.DbType = DbType.String;
            inputName.Value = name;
            inputName.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputName);

            SqlParameter inputDes = new SqlParameter();
            inputDes.ParameterName = "@describtion";
            inputDes.DbType = DbType.String;
            inputDes.Value = describtion;
            inputDes.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputDes);

            SqlParameter inputTutor = new SqlParameter();
            inputTutor.ParameterName = "@tutor_id";
            inputTutor.DbType = DbType.Int32;
            inputTutor.Value = tutor_id;
            inputTutor.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputTutor);

            // 3. create output parameters
            SqlParameter output = new SqlParameter();
            output.ParameterName = "@result";
            output.DbType = DbType.Int32;
            output.Direction = ParameterDirection.Output;
            command.Parameters.Add(output);

            // 4. execute procedure
            int ret = db.ExecuteNonQuery(command);

            // 5. get values of the output parameters
            string result = command.Parameters["@result"].Value.ToString();

            if (pDb == null)
            {
                db.Close();
            }
            return result;
        }
    }
}
