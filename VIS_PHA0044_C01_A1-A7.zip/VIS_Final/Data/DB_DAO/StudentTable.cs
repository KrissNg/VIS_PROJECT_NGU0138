﻿
using Data.Table;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.DB_DAO
{
    public class StudentTable
    {
        public static String SQL_SELECT = "SELECT * FROM \"Student\"";
        public static String SQL_SELECT_ID = "SELECT * FROM \"Student\" WHERE id=@id";
        public static String SQL_INSERT = "INSERT INTO \"Student\"(fname,lname,age,gender,grade,credit) VALUES (@fname, @lname,@age, @gender, @grade, @credit)";
        public static String SQL_DELETE_ID = "DELETE FROM \"Student\" WHERE id=@id";
        public static String SQL_UPDATE = "UPDATE \"Student\" SET fname=@fname, lname=@lname, age=@age, gender=@gender, email=@email, grade=@grade, credit=@credit WHERE id = @id";
        public static String SQL_Select_Credit = "Select credit from student where id = @id";
        public static String SQL_Update_Student = "Update student set email=@email, phone=@phone where fname=@fname";

        private static void PrepareUpdateCommand(SqlCommand command, string name, string email, int phone)
        {
            command.Parameters.AddWithValue("@fname", name);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@phone", phone);
        }

        public static int UpdateStudent(string name, string email, int phone)
        {
            Database db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_Update_Student);
            PrepareUpdateCommand(command, name, email, phone);
            int ret = db.ExecuteNonQuery(command);

            db.Close();
            return ret;
        }


        public static int ReadCredit(SqlDataReader reader)
        {
            int credit = 0;

            while (reader.Read())
            {
                credit = reader.GetInt32(0);

            }
            return credit;

        }

        public static int SelectCredit(int id)
        {
            Database db;

            db = new Database();
            db.Connect();


            SqlCommand command = db.CreateCommand(SQL_Select_Credit);

            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = db.Select(command);

            int credit = ReadCredit(reader);

            reader.Close();

            return credit;
        }

        public static int Insert(StudentDB student)
        {
            Database db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_INSERT);
            PrepareCommand(command, student);
            int ret = db.ExecuteNonQuery(command);

            db.Close();
            return ret;
        }

        /// <summary>
        /// Update the record.
        /// </summary>
        public static int Update(StudentDB student)
        {
            Database db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_UPDATE);
            PrepareCommand(command, student);
            int ret = db.ExecuteNonQuery(command);

            db.Close();
            return ret;
        }


        /// <summary>
        /// Select the records.
        /// </summary>
        public static Collection<StudentDB> Select(Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            SqlCommand command = db.CreateCommand(SQL_SELECT);
            SqlDataReader reader = db.Select(command);

            Collection<StudentDB> students = Read(reader);
            reader.Close();

            if (pDb == null)
            {
                db.Close();
            }

            return students;
        }

        /// <summary>
        /// Select the record.
        /// </summary>
        /// <param name="id">student id</param>
        public static StudentDB Select(int id)
        {
            Database db;

            db = new Database();
            db.Connect();


            SqlCommand command = db.CreateCommand(SQL_SELECT_ID);

            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = db.Select(command);

            Collection<StudentDB> Students = Read(reader);
            StudentDB StudentDB = null;
            if (Students.Count == 1)
            {
                StudentDB = Students[0];
            }
            reader.Close();

            db.Close();
            return StudentDB;
        }

        /// <summary>
        /// Delete the record.
        /// </summary>
        /// <param name="idUser">student id</param>
        /// <returns></returns>
        public static int Delete(int idUser, Database pDb = null)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }
            SqlCommand command = db.CreateCommand(SQL_DELETE_ID);

            command.Parameters.AddWithValue("@id", idUser);
            int ret = db.ExecuteNonQuery(command);

            if (pDb == null)
            {
                db.Close();
            }

            return ret;
        }

        /// <summary>
        ///  Prepare a command.
        /// </summary>
        private static void PrepareCommand(SqlCommand command, StudentDB StudentDB)
        { 
            command.Parameters.AddWithValue("@fname", StudentDB.fname);
            command.Parameters.AddWithValue("@lname", StudentDB.lname);
            command.Parameters.AddWithValue("@age", StudentDB.age);
            command.Parameters.AddWithValue("@gender", StudentDB.gender);
            command.Parameters.AddWithValue("@grade", StudentDB.grade);
            command.Parameters.AddWithValue("@credit", StudentDB.credit);
        }

        private static Collection<StudentDB> Read(SqlDataReader reader)
        {
            Collection<StudentDB> students = new Collection<StudentDB>();

            while (reader.Read())
            {
                int i = -1;
                StudentDB student = new StudentDB();
                student.id = reader.GetInt32(++i);
                student.fname = reader.GetString(++i);
                student.lname = reader.GetString(++i);
                student.age = reader.GetInt32(++i);
                student.gender = reader.GetInt32(++i);
                student.email = reader.GetString(++i);
                student.grade = reader.GetInt32(++i);
                student.credit = reader.GetInt32(++i);
                students.Add(student);
            }
            return students;
        }

        public static string CreateUser(string fname, string lname, int age, int grade, int credit, Database pDb)
        {
            Database db;
            if (pDb == null)
            {
                db = new Database();
                db.Connect();
            }
            else
            {
                db = (Database)pDb;
            }

            // 1.  create a command object identifying the stored procedure
            SqlCommand command = db.CreateCommand("CreateUser");

            // 2. set the command object so it knows to execute a stored procedure
            command.CommandType = CommandType.StoredProcedure;

            // 3. create input parameters

            SqlParameter inputFname = new SqlParameter();
            inputFname.ParameterName = "@fname";
            inputFname.DbType = DbType.String;
            inputFname.Value = fname;
            inputFname.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputFname);

            SqlParameter inputLname = new SqlParameter();
            inputLname.ParameterName = "@lname";
            inputLname.DbType = DbType.String;
            inputLname.Value = lname;
            inputLname.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputLname);

            SqlParameter inputAge = new SqlParameter();
            inputAge.ParameterName = "@age";
            inputAge.DbType = DbType.Int32;
            inputAge.Value = age;
            inputAge.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputAge);

            SqlParameter inputGrade = new SqlParameter();
            inputGrade.ParameterName = "@gade";
            inputGrade.DbType = DbType.Int32;
            inputGrade.Value = grade;
            inputGrade.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputGrade);

            SqlParameter inputCredit = new SqlParameter();
            inputCredit.ParameterName = "@credit";
            inputCredit.DbType = DbType.Int32;
            inputCredit.Value = credit;
            inputCredit.Direction = ParameterDirection.Input;
            command.Parameters.Add(inputCredit);

            // 3. create output parameters
            SqlParameter output = new SqlParameter();
            output.ParameterName = "@result";
            output.DbType = DbType.Int32;
            output.Direction = ParameterDirection.Output;
            command.Parameters.Add(output);

            // 4. execute procedure
            int ret = db.ExecuteNonQuery(command);

            // 5. get values of the output parameters
            string result = command.Parameters["@result"].Value.ToString();

            if (pDb == null)
            {
                db.Close();
            }
            return result;
        }
    }
}
