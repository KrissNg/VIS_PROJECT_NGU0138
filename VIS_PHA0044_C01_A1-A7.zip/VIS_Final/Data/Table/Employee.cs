﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Table
{
    class Employee
    {
        public int id { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public int age { get; set; }
        public string email { get; set; }
        public int phone { get; set; }
        public int tutor_id { get; set; }
        public int manager_id { get; set; }
        public int admin_id { get; set; }
    }
}
