﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Table
{
    public class StudentDB
    {
        public int id { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public int age { get; set; }
        public int gender { get; set; }
        public string email { get; set; }
        public int phone { get;set; }
        public int grade { get; set; }
        public int credit { get; set; }
        public int fts_id { get; set; }
        public int pts_id { get; set; }
        public int year_id { get; set; }

    }
}
