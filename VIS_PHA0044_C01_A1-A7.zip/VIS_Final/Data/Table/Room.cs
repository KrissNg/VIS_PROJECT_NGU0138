﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Table
{
    class Room
    {
        public int id { get; set; }
        public string name { get; set; }
        public int course_id { get; set; }
    }
}
