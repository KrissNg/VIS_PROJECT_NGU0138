﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Table
{
    public class CourseDB
    {
        public int id { get; set; }
        public string name { get; set; }
        public int credit { get; set; }
        public int student_id { get; set; }

    }
}
